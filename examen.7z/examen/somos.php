<section class= "container-fluid">
<!--<h2 class="text-center">Quien soy</h2>--> 
    <div class="row mt-5">
        <div class="col-xl-5 col-lg-6 col-xs-12 p-4">
            <img class="skills" src= "<?php echo base_url() ?>assets/img/articulocuero1.jpg" width="400px" height="auto">
            
    
        </div>
        <div class="col-xl-7 col-lg-6 col-xs-12 p-5" >
            <h1 align="center">Instituto Libertad</h1>
            <p align="justify">Surge como una alternativa educativa diferente. 
            </p>

        </div>
    </div>

    <div class="row mt-5">
        <div class="col-xl-7 col-lg-6 col-xs-12 p-5">
            <p align="justify">
                Las ganas de enseñar y el profesionalismo de nuestro equipo es lo que nos diferencia.
            
                Así como los desafíos y técnicas nuevas para crear, diseñar y (hoy en día) restaurar artesanías en cuero.
            </p>
            
    
        </div>
        
    </div>




        
 

</section>

